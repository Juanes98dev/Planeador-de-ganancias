import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, KeyboardAvoidingView, Modal, Platform, Pressable, SafeAreaView,
  ScrollView, StyleSheet, Text, TextInput, View
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as SQLite from 'expo-sqlite';

type Month = { id: number; year: number; month: number };
type Expense = { id: number; month_id: number; concept: string; amount: number; paid: number };
type Goal = { id: number; month_id: number; date: string; amount: number };

const dbPromise = SQLite.openDatabaseAsync('planeador.db');
const PURPLE = '#7C3AED';
const BLACK = '#111111';
const WHITE = '#FFFFFF';
const GREEN = '#16803D';
const RED = '#C62828';
const MUTED = '#777777';
const monthNames = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
const weekdays = ['L','M','X','J','V','S','D'];

function money(value: number) {
  return '$' + Math.round(value).toLocaleString('es-CO') + ' COP';
}
function monthLabel(month: number, year: number) {
  return `${monthNames[month - 1]} ${year}`;
}
function dateKey(year: number, month: number, day: number) {
  return `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
}
function dateLabel(key: string) {
  const [y,m,d] = key.split('-').map(Number);
  const date = new Date(y, m - 1, d, 12);
  const weekday = ['domingo','lunes','martes','miércoles','jueves','viernes','sábado'][date.getDay()];
  return `${weekday.charAt(0).toUpperCase() + weekday.slice(1)}, ${d} de ${monthNames[m - 1].toLowerCase()} de ${y}`;
}

export default function App() {
  const [ready, setReady] = useState(false);
  const [name, setName] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [months, setMonths] = useState<Month[]>([]);
  const [selected, setSelected] = useState<Month | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [modal, setModal] = useState<'month'|'expense'|'goal'|null>(null);
  const [monthInput, setMonthInput] = useState(String(new Date().getMonth() + 1));
  const [yearInput, setYearInput] = useState(String(new Date().getFullYear()));
  const [conceptInput, setConceptInput] = useState('');
  const [amountInput, setAmountInput] = useState('');
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);

  useEffect(() => {
    (async () => {
      const db = await dbPromise;
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS profile (id INTEGER PRIMARY KEY CHECK (id = 1), name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS months (id INTEGER PRIMARY KEY AUTOINCREMENT, year INTEGER NOT NULL, month INTEGER NOT NULL, UNIQUE(year, month));
        CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, month_id INTEGER NOT NULL, concept TEXT NOT NULL, amount REAL NOT NULL, paid INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS goals (id INTEGER PRIMARY KEY AUTOINCREMENT, month_id INTEGER NOT NULL, date TEXT NOT NULL, amount REAL NOT NULL, UNIQUE(month_id, date));
      `);
      const profile = await db.getFirstAsync<{name:string}>('SELECT name FROM profile WHERE id = 1');
      if (profile?.name) setName(profile.name);
      await refreshMonths();
      setReady(true);
    })().catch(e => Alert.alert('Error', 'No se pudo iniciar la base de datos: ' + String(e)));
  }, []);

  async function refreshMonths() {
    const db = await dbPromise;
    const rows = await db.getAllAsync<Month>('SELECT id, year, month FROM months ORDER BY year DESC, month DESC');
    setMonths(rows);
  }
  async function saveName() {
    const clean = nameInput.trim();
    if (!clean) return Alert.alert('Falta tu nombre', 'Escribe tu nombre para continuar.');
    const db = await dbPromise;
    await db.runAsync('INSERT INTO profile (id, name) VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET name = excluded.name', clean);
    setName(clean);
  }
  async function openMonth(m: Month) {
    setSelected(m);
    const db = await dbPromise;
    const e = await db.getAllAsync<Expense>('SELECT * FROM expenses WHERE month_id = ? ORDER BY id DESC', m.id);
    const g = await db.getAllAsync<Goal>('SELECT * FROM goals WHERE month_id = ? ORDER BY date', m.id);
    setExpenses(e); setGoals(g);
  }
  async function createMonth() {
    const mo = Number(monthInput), yr = Number(yearInput);
    if (!Number.isInteger(mo) || mo < 1 || mo > 12 || !Number.isInteger(yr) || yr < 2000 || yr > 2200) {
      return Alert.alert('Datos inválidos', 'Introduce un mes entre 1 y 12 y un año válido.');
    }
    const db = await dbPromise;
    try {
      await db.runAsync('INSERT INTO months (year, month) VALUES (?, ?)', yr, mo);
      setModal(null); await refreshMonths();
    } catch {
      Alert.alert('Mes existente', 'Ese mes y año ya están creados.');
    }
  }
  function resetExpenseForm(e?: Expense) {
    setEditingExpense(e ?? null); setConceptInput(e?.concept ?? ''); setAmountInput(e ? String(e.amount) : ''); setModal('expense');
  }
  async function saveExpense() {
    if (!selected) return;
    const concept = conceptInput.trim();
    const amount = Number(amountInput.replace(/\./g, '').replace(',', '.'));
    if (!concept) return Alert.alert('Falta el concepto', 'Escribe qué gasto quieres registrar.');
    if (!amountInput.trim() || !Number.isFinite(amount) || amount <= 0) return Alert.alert('Valor inválido', 'Introduce un valor mayor que cero.');
    const db = await dbPromise;
    if (editingExpense) await db.runAsync('UPDATE expenses SET concept = ?, amount = ? WHERE id = ?', concept, amount, editingExpense.id);
    else await db.runAsync('INSERT INTO expenses (month_id, concept, amount, paid) VALUES (?, ?, ?, 0)', selected.id, concept, amount);
    setModal(null); await openMonth(selected);
  }
  async function togglePaid(e: Expense) {
    const db = await dbPromise;
    await db.runAsync('UPDATE expenses SET paid = ? WHERE id = ?', e.paid ? 0 : 1, e.id);
    if (selected) await openMonth(selected);
  }
  function deleteExpense(e: Expense) {
    Alert.alert('Eliminar gasto', `¿Quieres eliminar "${e.concept}"?`, [
      {text:'Cancelar', style:'cancel'},
      {text:'Eliminar', style:'destructive', onPress: async () => {
        const db = await dbPromise; await db.runAsync('DELETE FROM expenses WHERE id = ?', e.id);
        if (selected) await openMonth(selected);
      }}
    ]);
  }
  function resetGoalForm(date: string, g?: Goal) {
    setSelectedDate(date); setEditingGoal(g ?? null); setAmountInput(g ? String(g.amount) : ''); setModal('goal');
  }
  async function saveGoal() {
    if (!selected) return;
    const raw = amountInput.trim();
    const amount = Number(raw.replace(/\./g, '').replace(',', '.'));
    if (!raw || !Number.isFinite(amount) || amount < 0) return Alert.alert('Valor inválido', 'Introduce cero o un valor positivo.');
    const db = await dbPromise;
    if (editingGoal) await db.runAsync('UPDATE goals SET amount = ? WHERE id = ?', amount, editingGoal.id);
    else await db.runAsync('INSERT INTO goals (month_id, date, amount) VALUES (?, ?, ?)', selected.id, selectedDate, amount);
    setModal(null); await openMonth(selected);
  }
  function deleteGoal() {
    if (!editingGoal || !selected) return;
    Alert.alert('Eliminar meta', '¿Quieres eliminar la meta de este día?', [
      {text:'Cancelar', style:'cancel'},
      {text:'Eliminar', style:'destructive', onPress: async () => {
        const db = await dbPromise; await db.runAsync('DELETE FROM goals WHERE id = ?', editingGoal.id);
        setModal(null); await openMonth(selected);
      }}
    ]);
  }

  const totals = useMemo(() => {
    const expensesTotal = expenses.reduce((s, e) => s + e.amount, 0);
    const paidTotal = expenses.reduce((s, e) => s + (e.paid ? e.amount : 0), 0);
    const planned = goals.reduce((s, g) => s + g.amount, 0);
    return { expensesTotal, paidTotal, pending: expensesTotal - paidTotal, planned, balance: planned - expensesTotal };
  }, [expenses, goals]);

  const calendarCells = useMemo(() => {
    if (!selected) return [];
    const firstDay = new Date(selected.year, selected.month - 1, 1).getDay();
    const offset = (firstDay + 6) % 7; // Monday first
    const days = new Date(selected.year, selected.month, 0).getDate();
    const count = Math.ceil((offset + days) / 7) * 7;
    return Array.from({length: count}, (_, i) => {
      const day = i - offset + 1;
      return day >= 1 && day <= days ? day : null;
    });
  }, [selected]);

  if (!ready) return <SafeAreaView style={styles.center}><Text style={styles.loading}>Preparando tu planeador…</Text></SafeAreaView>;

  if (!name) return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <View style={styles.welcome}>
        <View style={styles.logo}><Text style={styles.logoText}>PG</Text></View>
        <Text style={styles.welcomeTitle}>Tu dinero,{"\n"}bajo control.</Text>
        <Text style={styles.welcomeCopy}>Planea tus gastos y define cuánto quieres ganar cada mes.</Text>
        <Text style={styles.fieldLabel}>¿Cómo te llamas?</Text>
        <TextInput value={nameInput} onChangeText={setNameInput} placeholder="Escribe tu nombre" placeholderTextColor="#999" style={styles.input} autoCapitalize="words" returnKeyType="done" onSubmitEditing={saveName} />
        <Pressable style={styles.primaryButton} onPress={saveName}><Text style={styles.primaryButtonText}>Continuar</Text></Pressable>
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.topBar}>
        {selected ? <Pressable onPress={() => setSelected(null)} style={styles.backButton}><Text style={styles.backText}>‹ Meses</Text></Pressable> : <View style={styles.logoSmall}><Text style={styles.logoSmallText}>PG</Text></View>}
        <Text style={styles.topBarTitle}>{selected ? monthLabel(selected.month, selected.year) : 'Planeador'}</Text>
        <View style={{width:64}} />
      </View>

      {!selected ? (
        <ScrollView contentContainerStyle={styles.page}>
          <Text style={styles.greeting}>Bienvenido, {name}</Text>
          <Text style={styles.subtitle}>Organiza tus gastos y tus metas de ingresos.</Text>
          <Pressable style={styles.primaryButton} onPress={() => {setMonthInput(String(new Date().getMonth()+1));setYearInput(String(new Date().getFullYear()));setModal('month');}}>
            <Text style={styles.primaryButtonText}>＋ Añadir mes</Text>
          </Pressable>
          <Text style={styles.sectionTitle}>Tus meses</Text>
          {months.length === 0 ? (
            <View style={styles.emptyCard}><Text style={styles.emptyTitle}>Tu planeador empieza aquí</Text><Text style={styles.muted}>Añade tu primer mes para registrar gastos y metas diarias.</Text></View>
          ) : months.map(m => (
            <Pressable key={m.id} onPress={() => openMonth(m)} style={styles.monthCard}>
              <View><Text style={styles.monthName}>{monthLabel(m.month, m.year)}</Text><Text style={styles.muted}>Gastos y metas de ingresos</Text></View>
              <Text style={styles.chevron}>›</Text>
            </Pressable>
          ))}
        </ScrollView>
      ) : (
        <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
          <Text style={styles.sectionTitle}>1. Gastos del mes</Text>
          <Pressable style={styles.outlineButton} onPress={() => resetExpenseForm()}><Text style={styles.outlineButtonText}>＋ Añadir gasto</Text></Pressable>
          {expenses.length === 0 ? <View style={styles.emptyCard}><Text style={styles.muted}>Todavía no has registrado gastos.</Text></View> : expenses.map(e => (
            <View key={e.id} style={styles.expenseRow}>
              <Pressable onPress={() => togglePaid(e)} style={[styles.checkbox, e.paid ? styles.checkboxOn : null]}><Text style={styles.checkText}>{e.paid ? '✓' : ''}</Text></Pressable>
              <View style={styles.expenseInfo}><Text style={[styles.expenseConcept, e.paid ? styles.paidText : null]}>{e.concept}</Text><Text style={styles.muted}>{e.paid ? 'Pagado' : 'Pendiente'}</Text></View>
              <Text style={styles.expenseAmount}>{money(e.amount)}</Text>
              <View style={styles.smallActions}>
                <Pressable onPress={() => resetExpenseForm(e)}><Text style={styles.actionText}>Editar</Text></Pressable>
                <Pressable onPress={() => deleteExpense(e)}><Text style={[styles.actionText, {color:RED}]}>Borrar</Text></Pressable>
              </View>
            </View>
          ))}
          <View style={styles.statsCard}>
            <Stat label="Total gastos" value={money(totals.expensesTotal)} />
            <Stat label="Pagados" value={money(totals.paidTotal)} />
            <Stat label="Pendientes" value={money(totals.pending)} />
          </View>

          <Text style={[styles.sectionTitle, {marginTop:26}]}>2. Metas diarias</Text>
          <Text style={styles.muted}>Toca un día para agregar o editar lo que planeas ganar.</Text>
          <View style={styles.calendar}>
            <View style={styles.weekHeader}>{weekdays.map((d, i) => <Text key={i} style={styles.weekday}>{d}</Text>)}</View>
            <View style={styles.calendarGrid}>
              {calendarCells.map((day, i) => {
                const key = day ? dateKey(selected.year, selected.month, day) : '';
                const goal = goals.find(g => g.date === key);
                return <Pressable key={i} disabled={!day} onPress={() => resetGoalForm(key, goal)} style={[styles.dayCell, !day && styles.blankDay, goal && styles.dayWithGoal]}>
                  {day ? <><Text style={styles.dayNumber}>{day}</Text>{goal ? <Text numberOfLines={1} style={styles.dayGoal}>{shortMoney(goal.amount)}</Text> : null}</> : null}
                </Pressable>;
              })}
            </View>
          </View>
          <View style={styles.statsCard}>
            <Stat label="Planeado en el mes" value={money(totals.planned)} />
            <Stat label="Días con meta" value={String(goals.length)} />
            <Stat label="Promedio por día con meta" value={money(goals.length ? totals.planned / goals.length : 0)} />
          </View>

          <Text style={[styles.sectionTitle, {marginTop:26}]}>3. Comparación mensual</Text>
          <View style={styles.compareRow}>
            <View style={styles.compareCard}><Text style={styles.compareLabel}>Gastos totales</Text><Text style={styles.compareValue}>{money(totals.expensesTotal)}</Text></View>
            <View style={styles.compareCard}><Text style={styles.compareLabel}>Ingresos planeados</Text><Text style={styles.compareValue}>{money(totals.planned)}</Text></View>
          </View>
          <View style={styles.balanceCard}>
            <Text style={styles.compareLabel}>Balance planeado</Text>
            <Text style={[styles.balanceValue, {color: totals.balance > 0 ? GREEN : totals.balance < 0 ? RED : MUTED}]}>{totals.balance > 0 ? '+' : ''}{money(totals.balance)}</Text>
            <Text style={[styles.balanceStatus, {color: totals.balance > 0 ? GREEN : totals.balance < 0 ? RED : MUTED}]}>
              {totals.balance > 0 ? 'Vas por encima de tus gastos' : totals.balance < 0 ? 'Tus metas aún no cubren los gastos' : 'Estás en equilibrio'}
            </Text>
          </View>
          <Text style={styles.footerNote}>Las metas representan ingresos planeados, no ingresos confirmados.</Text>
        </ScrollView>
      )}

      <Modal visible={modal !== null} transparent animationType="slide" onRequestClose={() => setModal(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.modalBackdrop}>
          <Pressable style={styles.modalOutside} onPress={() => setModal(null)} />
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>{modal === 'month' ? 'Añadir mes' : modal === 'expense' ? (editingExpense ? 'Editar gasto' : 'Nuevo gasto') : (editingGoal ? 'Editar meta diaria' : 'Nueva meta diaria')}</Text>
            {modal === 'month' ? <>
              <Text style={styles.fieldLabel}>Mes (1 a 12)</Text>
              <TextInput style={styles.input} value={monthInput} onChangeText={setMonthInput} keyboardType="number-pad" placeholder="11" />
              <Text style={styles.fieldLabel}>Año</Text>
              <TextInput style={styles.input} value={yearInput} onChangeText={setYearInput} keyboardType="number-pad" placeholder="2026" />
              <Text style={styles.muted}>1 = enero, 12 = diciembre.</Text>
              <Pressable style={styles.primaryButton} onPress={createMonth}><Text style={styles.primaryButtonText}>Crear mes</Text></Pressable>
            </> : modal === 'expense' ? <>
              <Text style={styles.fieldLabel}>Concepto</Text>
              <TextInput style={styles.input} value={conceptInput} onChangeText={setConceptInput} placeholder="Ej. Arriendo" placeholderTextColor="#999" />
              <Text style={styles.fieldLabel}>Valor en COP</Text>
              <TextInput style={styles.input} value={amountInput} onChangeText={setAmountInput} keyboardType="decimal-pad" placeholder="300000" placeholderTextColor="#999" />
              <Pressable style={styles.primaryButton} onPress={saveExpense}><Text style={styles.primaryButtonText}>{editingExpense ? 'Guardar cambios' : 'Añadir gasto'}</Text></Pressable>
            </> : <>
              <Text style={styles.fieldLabel}>Fecha</Text>
              <Text style={styles.dateText}>{dateLabel(selectedDate)}</Text>
              <Text style={styles.fieldLabel}>Meta de ingresos en COP</Text>
              <TextInput style={styles.input} value={amountInput} onChangeText={setAmountInput} keyboardType="decimal-pad" placeholder="300000" placeholderTextColor="#999" />
              <Pressable style={styles.primaryButton} onPress={saveGoal}><Text style={styles.primaryButtonText}>{editingGoal ? 'Guardar cambios' : 'Guardar meta'}</Text></Pressable>
              {editingGoal ? <Pressable style={styles.deleteGoalButton} onPress={deleteGoal}><Text style={styles.deleteGoalText}>Eliminar meta</Text></Pressable> : null}
            </>}
            <Pressable style={styles.cancelButton} onPress={() => setModal(null)}><Text style={styles.cancelText}>Cancelar</Text></Pressable>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

function shortMoney(v: number) {
  if (v >= 1000000) return `$${(v/1000000).toLocaleString('es-CO',{maximumFractionDigits:1})}M`;
  if (v >= 1000) return `$${Math.round(v/1000)}k`;
  return `$${Math.round(v)}`;
}
function Stat({label, value}: {label:string; value:string}) {
  return <View style={styles.statRow}><Text style={styles.statLabel}>{label}</Text><Text style={styles.statValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:WHITE},
  center:{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:WHITE},
  loading:{color:BLACK,fontSize:16},
  welcome:{flex:1,backgroundColor:BLACK,padding:28,justifyContent:'center'},
  logo:{width:58,height:58,borderRadius:18,backgroundColor:PURPLE,alignItems:'center',justifyContent:'center',marginBottom:28},
  logoText:{color:WHITE,fontWeight:'900',fontSize:20},
  welcomeTitle:{color:WHITE,fontSize:36,fontWeight:'800',lineHeight:42},
  welcomeCopy:{color:'#C8C8C8',fontSize:16,lineHeight:23,marginTop:14,marginBottom:34},
  fieldLabel:{fontSize:14,fontWeight:'700',color:BLACK,marginTop:12,marginBottom:7},
  input:{borderWidth:1,borderColor:'#E2E2E2',backgroundColor:WHITE,color:BLACK,borderRadius:12,paddingHorizontal:14,paddingVertical:13,fontSize:16,marginBottom:8},
  primaryButton:{backgroundColor:PURPLE,borderRadius:13,paddingVertical:15,paddingHorizontal:18,alignItems:'center',justifyContent:'center',marginTop:12},
  primaryButtonText:{color:WHITE,fontWeight:'800',fontSize:16},
  topBar:{height:58,paddingHorizontal:18,flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderBottomWidth:1,borderBottomColor:'#EEEEEE'},
  topBarTitle:{fontSize:16,fontWeight:'800',color:BLACK,textAlign:'center',flex:1},
  logoSmall:{width:32,height:32,borderRadius:10,backgroundColor:PURPLE,alignItems:'center',justifyContent:'center'},
  logoSmallText:{fontSize:12,color:WHITE,fontWeight:'900'},
  backButton:{width:64},
  backText:{color:PURPLE,fontSize:15,fontWeight:'700'},
  page:{padding:20,paddingBottom:40},
  greeting:{fontSize:28,fontWeight:'900',color:BLACK,marginTop:8},
  subtitle:{fontSize:14,color:MUTED,marginTop:7,marginBottom:20,lineHeight:20},
  sectionTitle:{fontSize:20,fontWeight:'900',color:BLACK,marginTop:12,marginBottom:12},
  muted:{fontSize:13,color:MUTED,lineHeight:19},
  emptyCard:{borderWidth:1,borderColor:'#EAEAEA',borderRadius:16,padding:20,marginTop:8,backgroundColor:'#FAFAFA'},
  emptyTitle:{fontWeight:'800',fontSize:16,color:BLACK,marginBottom:6},
  monthCard:{borderWidth:1,borderColor:'#EAEAEA',borderRadius:16,padding:17,marginTop:10,flexDirection:'row',alignItems:'center',justifyContent:'space-between',backgroundColor:WHITE},
  monthName:{fontSize:17,fontWeight:'800',color:BLACK,marginBottom:5},
  chevron:{fontSize:30,color:PURPLE},
  outlineButton:{borderWidth:1.5,borderColor:PURPLE,borderRadius:12,padding:13,alignItems:'center',marginBottom:10},
  outlineButtonText:{color:PURPLE,fontSize:15,fontWeight:'800'},
  expenseRow:{borderBottomWidth:1,borderBottomColor:'#EEEEEE',paddingVertical:13,flexDirection:'row',alignItems:'center',gap:9},
  checkbox:{width:23,height:23,borderRadius:7,borderWidth:1.5,borderColor:'#B9B9B9',alignItems:'center',justifyContent:'center'},
  checkboxOn:{backgroundColor:PURPLE,borderColor:PURPLE},
  checkText:{color:WHITE,fontWeight:'900',fontSize:14},
  expenseInfo:{flex:1},
  expenseConcept:{fontSize:14,fontWeight:'700',color:BLACK},
  paidText:{textDecorationLine:'line-through',color:MUTED},
  expenseAmount:{fontSize:12,fontWeight:'700',color:BLACK},
  smallActions:{flexDirection:'row',gap:8,marginLeft:2},
  actionText:{fontSize:11,color:PURPLE,fontWeight:'700'},
  statsCard:{borderRadius:15,backgroundColor:'#F7F5FC',padding:15,marginTop:14},
  statRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingVertical:5,gap:12},
  statLabel:{fontSize:13,color:'#5D5D5D',flex:1},
  statValue:{fontSize:13,color:BLACK,fontWeight:'800',textAlign:'right',flexShrink:1},
  calendar:{borderWidth:1,borderColor:'#E8E4F2',borderRadius:16,padding:8,marginTop:14,backgroundColor:WHITE},
  weekHeader:{flexDirection:'row',marginBottom:6},
  weekday:{width:'14.2857%',textAlign:'center',fontSize:12,fontWeight:'800',color:MUTED,paddingVertical:7},
  calendarGrid:{flexDirection:'row',flexWrap:'wrap'},
  dayCell:{width:'14.2857%',minHeight:64,borderWidth:1,borderColor:'#EEEAF5',borderRadius:8,marginBottom:3,padding:4,alignItems:'flex-start',backgroundColor:WHITE},
  blankDay:{borderColor:'transparent',backgroundColor:'transparent'},
  dayWithGoal:{backgroundColor:'#F1EAFE',borderColor:'#D8C5FF'},
  dayNumber:{fontSize:13,fontWeight:'800',color:BLACK},
  dayGoal:{fontSize:9,color:PURPLE,fontWeight:'900',marginTop:5},
  compareRow:{flexDirection:'row',gap:10},
  compareCard:{flex:1,borderWidth:1,borderColor:'#EAEAEA',borderRadius:15,padding:14,minHeight:96},
  compareLabel:{fontSize:12,color:MUTED,fontWeight:'700',marginBottom:10},
  compareValue:{fontSize:15,fontWeight:'900',color:BLACK},
  balanceCard:{marginTop:12,borderRadius:16,padding:18,backgroundColor:'#F8F8F8',alignItems:'center'},
  balanceValue:{fontSize:27,fontWeight:'900'},
  balanceStatus:{fontSize:13,fontWeight:'700',marginTop:5,textAlign:'center'},
  footerNote:{fontSize:11,color:MUTED,textAlign:'center',marginTop:14,lineHeight:17},
  modalBackdrop:{flex:1,justifyContent:'flex-end',backgroundColor:'rgba(0,0,0,0.45)'},
  modalOutside:{flex:1},
  modalCard:{backgroundColor:WHITE,borderTopLeftRadius:24,borderTopRightRadius:24,padding:22,paddingBottom:30},
  modalTitle:{fontSize:22,fontWeight:'900',color:BLACK,marginBottom:8},
  dateText:{fontSize:15,fontWeight:'700',color:PURPLE,marginBottom:8},
  cancelButton:{padding:13,alignItems:'center',marginTop:4},
  cancelText:{color:MUTED,fontWeight:'700'},
  deleteGoalButton:{padding:10,alignItems:'center',marginTop:6},
  deleteGoalText:{color:RED,fontWeight:'800'}
});
