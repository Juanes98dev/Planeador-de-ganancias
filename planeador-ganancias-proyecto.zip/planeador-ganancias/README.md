# Planeador de Ganancias

Aplicación móvil en React Native + Expo + TypeScript. Guarda nombre, meses, gastos y metas diarias localmente con SQLite. No requiere backend.

## Requisitos
- Node.js LTS
- Una cuenta de Expo para compilar con EAS
- Android: teléfono físico o emulador
- iOS: iPhone y herramientas de Apple para distribución iOS

## Ejecutar localmente
```bash
npm install
npx expo start
```
Escanea el QR con Expo Go. Como el proyecto usa SQLite, revisa que tu versión de Expo Go sea compatible con el SDK instalado. Para una app instalada con sus propias funciones nativas, genera un development build.

## Generar un APK
```bash
npm install
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
```
EAS compilará el APK en la nube y mostrará un enlace cuando termine. Este repositorio es el código fuente; el APK no está incluido porque debe generarse mediante el proceso de compilación.

## Generar iOS
```bash
npx eas-cli build --platform ios --profile preview
```
La distribución a dispositivos iOS requiere las credenciales y condiciones de Apple correspondientes. Para publicar en App Store, configura el perfil de producción y App Store Connect.

## Almacenamiento
Los datos se guardan en una base SQLite local del dispositivo. No se sincronizan automáticamente con otros dispositivos. Desinstalar la app puede borrar los datos locales; conserva copias de seguridad si son importantes.

## Funciones implementadas
- Primer inicio solicita nombre y luego saluda con él.
- Crear meses por mes y año; orden descendente; evita duplicados.
- Agregar, editar, pagar/desmarcar y eliminar gastos.
- Calendario de lunes a domingo, acorde al mes/año.
- Una meta de ingresos por día, editable y eliminable.
- Totales de gastos pagados y pendientes.
- Balance de ingresos planeados menos gastos, con estados verde/rojo/neutral.
